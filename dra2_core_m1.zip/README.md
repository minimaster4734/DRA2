# DRA2 core — game-specific GameCube runtime (milestone 1, Linux)

Clean-room runtime for running *your own* disc image of Digimon Rumble Arena 2 (GD6P70).
No Nintendo/Bandai/Atari code or data is included; the game's DOL is loaded from your disc at runtime.

## Build / run
    g++ -O2 -std=c++17 -o dra2core main.cpp cpu.cpp machine.cpp hw.cpp gx.cpp     # or: cmake + make
    python3 tools/rvz2iso.py game.rvz game.iso        # needs: pip install zstandard
    ./dra2core game.iso 1500                           # run N million instructions
    STATUS=1 DVDLOG=1 ./dra2core game.iso 3000         # progress + DVD reads by file name
    DSPDUMP=1 ./dra2core game.iso 900                  # dumps the DSP ucode the game uploads
    python3 tools/gcinfo.py game.iso files.txt         # DOL header + FST listing
    python3 tools/dasm.py main.dol 802C7F50 802C8000   # PPC disassembly (pip install capstone)

## Layout
- cpu.cpp     Gekko interpreter (integer, FPU, paired singles, GQR quantization, exceptions/interrupts)
- machine.cpp bus (24 MB RAM, ARAM, locked cache), DOL/FST boot, low-memory globals
- hw.cpp      register-level PI/VI/DI/EXI(RTC+SRAM)/AI/DSP-interface/PE/MI/CP; DSP boot-ROM mail protocol
- gx.cpp      GX command-stream parser (CP/XF/BP loads, vertex-size aware draw skipping, PE events)

## Status
Boots: OSInit -> DVD -> VI -> GXInit -> DSP boot task -> game main loop (~250 frames / 1.5 G instr, 125k verts).
Game loads boot Lua scripts + menu_black.res + memcard.res, then idles on a black screen (no pad input yet).

## Next
1. SI/PAD controller emulation (+ memory-card "absent" path)     2. GX -> GLES2 renderer (TEV shaders, EFB copies, textures)
3. DSP ucode HLE (ucode CRC32 4CB8233B, 0x1F20 bytes, entry 0x10) + AI DMA audio out     4. Android wrapper (NDK, armv7, GLES2)
5. Speed: block-cached interpreter / ARMv7 JIT
