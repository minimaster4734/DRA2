#include "gc.h"
#include <cstdlib>

int main(int argc, char** argv) {
  if (argc < 2) { fprintf(stderr, "usage: %s game.iso [max_million_instr] [-t]\n", argv[0]); return 1; }
  Machine* m = new Machine();
  m->bus.m = m; m->cpu.m = m; m->cpu.bus = &m->bus;
  for (int i = 3; i < argc; i++) if (!strcmp(argv[i], "-t")) m->trace = true;
  if (!m->loadIso(argv[1]) || !m->boot()) return 2;
  u64 maxI = (argc > 2 ? strtoull(argv[2], 0, 10) : 200) * 1000000ull;
  u64 nextRep = 0;
  while (!m->cpu.halted && m->cpu.icount < maxI) {
    m->cpu.step(4096); m->tick();
    if (getenv("STATUS") && m->cpu.icount >= nextRep) { nextRep += 100000000; fprintf(stderr, "[status] %4lluM pc=%08X draws=%llu finish=%llu efbcopy=%llu verts=%llu\n", (unsigned long long)(m->cpu.icount / 1000000), m->cpu.pc, (unsigned long long)m->gxStats.draws, (unsigned long long)m->gxStats.finish, (unsigned long long)m->gxStats.efbCopies, (unsigned long long)m->gxStats.verts); }
  }
  CPU& c = m->cpu;
  fprintf(stderr, "\n== stopped after %llu instr: %s\n", (unsigned long long)c.icount, c.halted ? c.haltReason.c_str() : "limit");
  fprintf(stderr, "pc=%08X lr=%08X ctr=%08X msr=%08X cr=%08X xer=%08X\n", c.pc, c.lr, c.ctr, c.msr, c.cr, c.xer);
  for (int i = 0; i < 32; i += 4) fprintf(stderr, "r%02d %08X %08X %08X %08X\n", i, c.gpr[i], c.gpr[i+1], c.gpr[i+2], c.gpr[i+3]);
  fprintf(stderr, "last pcs:"); for (int i = 16; i > 0; i--) fprintf(stderr, " %08X", c.pcHist[(c.pcHistPos - i) & 63]); fputc('\n', stderr);
  if (getenv("DUMP")) { u32 a = strtoul(getenv("DUMP"), 0, 16); for (int i = 0; i < 12; i++) fprintf(stderr, "%08X: %08X\n", a + i * 4, m->bus.r32(a + i * 4)); }
  { fprintf(stderr, "stack:"); u32 sp = c.gpr[1]; for (int i = 0; i < 12 && sp > 0x80000000u && sp < 0x81800000u; i++) { u32 nx = m->bus.r32(sp); fprintf(stderr, " %08X", m->bus.r32(nx + 4)); sp = nx; } fputc('\n', stderr); }
  for (int r = 3; r <= 10; r++) { u32 p = c.gpr[r]; if (p > 0x80000000u && p < 0x81800000u) { char b[80] = {0}; for (int i = 0; i < 79; i++) { u8 ch = m->bus.r8(p + i); if (!ch) break; b[i] = (ch >= 32 && ch < 127) ? ch : '.'; } fprintf(stderr, "r%d -> \"%s\"\n", r, b); } }
  fprintf(stderr, "gx: fifo=%zu consumed=%zu draws=%llu verts=%llu finish=%llu token=%llu efbcopy=%llu cp=%llu xf=%llu idxXF=%llu calldl=%llu\n", m->gxfifo.size(), m->gxPos, (unsigned long long)m->gxStats.draws, (unsigned long long)m->gxStats.verts, (unsigned long long)m->gxStats.finish, (unsigned long long)m->gxStats.token, (unsigned long long)m->gxStats.efbCopies, (unsigned long long)m->gxStats.cpLoads, (unsigned long long)m->gxStats.xfLoads, (unsigned long long)m->gxStats.indexedXf, (unsigned long long)m->gxStats.callDL);
  return 0;
}
