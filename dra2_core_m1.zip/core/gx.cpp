// GX command-processor stream parser. Consumes bytes written to the write-gather pipe.
// Rendering hooks (GLES2) are attached later; this stage tracks state and raises PE events.
#include "gc.h"

static inline u32 be32(const u8* p) { return (u32)p[0] << 24 | p[1] << 16 | p[2] << 8 | p[3]; }
static inline u16 be16(const u8* p) { return (u16)(p[0] << 8 | p[1]); }

static int fmtSize(int fmt) { static const int s[8] = {1, 1, 2, 2, 4, 4, 4, 4}; return s[fmt & 7]; }
static int colSize(int fmt) { static const int s[8] = {2, 3, 4, 2, 3, 4, 4, 4}; return s[fmt & 7]; }

// Bytes per vertex given current VCD/VAT
static int vertexSize(Machine& m, int vat) {
  u32 lo = m.cpRegs[0x50], hi = m.cpRegs[0x60];
  u32 a = m.cpRegs[0x70 + vat], b = m.cpRegs[0x80 + vat], c = m.cpRegs[0x90 + vat];
  int sz = 0;
  if (lo & 1) sz += 1;
  for (int i = 0; i < 8; i++) if (lo & (2u << i)) sz += 1;
  auto idx = [&](int mode, int direct) { return mode == 0 ? 0 : mode == 1 ? direct : mode == 2 ? 1 : 2; };
  int pos = (lo >> 9) & 3, nrm = (lo >> 11) & 3, c0 = (lo >> 13) & 3, c1 = (lo >> 15) & 3;
  sz += idx(pos, ((a & 1) ? 3 : 2) * fmtSize((a >> 1) & 7));
  if (nrm) {
    int cnt = (a >> 9) & 1 ? 9 : 3;
    int direct = cnt * fmtSize((a >> 10) & 7);
    if (nrm >= 2) { int n = (cnt == 9 && ((a >> 31) & 1)) ? 3 : 1; sz += n * (nrm == 2 ? 1 : 2); } else sz += direct;
  }
  sz += idx(c0, colSize((a >> 14) & 7));
  sz += idx(c1, colSize((a >> 18) & 7));
  int tcnt[8], tfmt[8];
  tcnt[0] = (a >> 21) & 1; tfmt[0] = (a >> 22) & 7;
  tcnt[1] = b & 1; tfmt[1] = (b >> 1) & 7;
  tcnt[2] = (b >> 9) & 1; tfmt[2] = (b >> 10) & 7;
  tcnt[3] = (b >> 18) & 1; tfmt[3] = (b >> 19) & 7;
  tcnt[4] = (b >> 27) & 1; tfmt[4] = (b >> 28) & 7;
  tcnt[5] = (c >> 5) & 1; tfmt[5] = (c >> 6) & 7;
  tcnt[6] = (c >> 14) & 1; tfmt[6] = (c >> 15) & 7;
  tcnt[7] = (c >> 23) & 1; tfmt[7] = (c >> 24) & 7;
  for (int i = 0; i < 8; i++) {
    int mode = (hi >> (i * 2)) & 3;
    sz += idx(mode, (tcnt[i] + 1) * fmtSize(tfmt[i]));
  }
  return sz;
}

void Machine::gxBP(u32 reg, u32 val) {
  bpRegs[reg] = val;
  switch (reg) {
    case 0x45:   // PE_DONE (draw done / finish)
      peReg[0x0A >> 1] |= 8; gxStats.finish++; updateInts(); break;
    case 0x47:   // PE_TOKEN
      gxStats.token = val & 0xFFFF; peReg[0x0E >> 1] = (u16)val; break;
    case 0x48:   // PE_TOKEN_INT
      gxStats.token = val & 0xFFFF; peReg[0x0E >> 1] = (u16)val; peReg[0x0A >> 1] |= 4; updateInts(); break;
    case 0x52: gxStats.efbCopies++; break;   // EFB copy (XFB or texture)
    default: break;
  }
}

void Machine::gxProcess() {
  const u8* d = gxfifo.data(); size_t n = gxfifo.size(), p = gxPos;
  while (p < n) {
    u8 cmd = d[p];
    size_t need = 1, len = 0;
    switch (cmd) {
      case 0x00: case 0x44: case 0x48: p++; continue;   // NOP, INVL_VC
      case 0x08: need = 6; if (p + need > n) goto done; cpRegs[d[p + 1]] = be32(d + p + 2); gxStats.cpLoads++; p += need; continue;
      case 0x10: { need = 5; if (p + need > n) goto done; u32 h = be32(d + p + 1); u32 cnt = (h >> 16) + 1; need = 5 + cnt * 4; if (p + need > n) goto done;
        u32 addr = h & 0xFFFF; for (u32 i = 0; i < cnt; i++) if (addr + i < 0x1100) xf[addr + i] = be32(d + p + 5 + i * 4); gxStats.xfLoads++; p += need; continue; }
      case 0x20: case 0x28: case 0x30: case 0x38: need = 5; if (p + need > n) goto done; gxStats.indexedXf++; p += need; continue;
      case 0x40: need = 9; if (p + need > n) goto done; gxStats.callDL++; p += need; continue;  // display list: executed by gxCallDL later
      case 0x61: need = 5; if (p + need > n) goto done; { u32 v = be32(d + p + 1); gxBP(v >> 24, v & 0xFFFFFF); } p += need; continue;
      default:
        if (cmd >= 0x80) {
          need = 3; if (p + need > n) goto done;
          int vat = cmd & 7, cnt = be16(d + p + 1), vs = vertexSize(*this, vat);
          need = 3 + (size_t)cnt * vs; if (p + need > n) goto done;
          gxStats.draws++; gxStats.verts += cnt; p += need; continue;
        }
        { char b[80]; snprintf(b, sizeof b, "GX: bad command 0x%02X at stream pos %zu", cmd, p); cpu.halt(b); gxPos = p; return; }
    }
  }
done:
  gxPos = p;
  if (gxPos > (1u << 22) && gxPos == gxfifo.size()) { gxfifo.clear(); gxPos = 0; }   // keep the buffer small
}
